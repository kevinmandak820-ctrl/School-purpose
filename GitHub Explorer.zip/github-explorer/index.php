<?php
session_start();
if (isset($_SESSION['user_id'])) {
    header('Location: pages/search.php');
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>GitHub Explorer</title>
  <link rel="stylesheet" href="css/style.css">
  <style>
    .hero {
      min-height: 100vh;
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      text-align: center;
      padding: 40px 24px;
      position: relative;
      overflow: hidden;
    }
    .hero::before {
      content: '';
      position: absolute;
      width: 700px; height: 700px;
      border-radius: 50%;
      background: radial-gradient(circle, rgba(88,166,255,0.07) 0%, transparent 65%);
      top: 50%; left: 50%;
      transform: translate(-50%, -50%);
      pointer-events: none;
    }
    .hero-icon {
      width: 80px; height: 80px;
      background: linear-gradient(135deg, #58a6ff, #bc8cff);
      border-radius: 20px;
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 2.4rem;
      margin: 0 auto 24px;
      box-shadow: 0 0 40px rgba(88,166,255,0.2);
    }
    .hero h1 {
      font-size: 3rem;
      font-weight: 700;
      font-family: var(--font-mono);
      background: linear-gradient(90deg, #e6edf3, #58a6ff);
      -webkit-background-clip: text;
      -webkit-text-fill-color: transparent;
      margin-bottom: 16px;
    }
    .hero p {
      font-size: 1.1rem;
      color: var(--text-secondary);
      max-width: 480px;
      margin: 0 auto 36px;
      line-height: 1.7;
    }
    .feature-grid {
      display: grid;
      grid-template-columns: repeat(3, 1fr);
      gap: 16px;
      max-width: 700px;
      margin: 0 auto 36px;
    }
    .feature-item {
      background: var(--bg-secondary);
      border: 1px solid var(--border);
      border-radius: 10px;
      padding: 18px;
      font-size: 0.875rem;
      color: var(--text-secondary);
    }
    .feature-item .fi { font-size: 1.5rem; margin-bottom: 8px; }
    .feature-item strong { display: block; color: var(--text-primary); margin-bottom: 4px; }
    @media (max-width: 600px) {
      .feature-grid { grid-template-columns: 1fr 1fr; }
      .hero h1 { font-size: 2rem; }
    }
  </style>
</head>
<body>
<div class="hero">
  <div class="hero-icon">⬡</div>
  <h1>GitExplorer</h1>
  <p>Search and explore GitHub repositories, save your favourites, and manage your developer workflow in one clean interface.</p>

  <div class="feature-grid">
    <div class="feature-item"><div class="fi">🔍</div><strong>Search</strong>Find any repo on GitHub instantly</div>
    <div class="feature-item"><div class="fi">★</div><strong>Star</strong>Save repos you love</div>
    <div class="feature-item"><div class="fi">📊</div><strong>Details</strong>Languages, contributors & README</div>
    <div class="feature-item"><div class="fi">👤</div><strong>Profile</strong>Track your activity</div>
    <div class="feature-item"><div class="fi">🕑</div><strong>History</strong>Search history saved</div>
    <div class="feature-item"><div class="fi">⚙</div><strong>Settings</strong>API token & preferences</div>
  </div>

  <div style="display:flex;gap:12px;">
    <a href="pages/login.php" class="btn btn-primary" style="padding:12px 32px;font-size:1rem;">Get Started →</a>
    <a href="pages/login.php" class="btn btn-secondary" style="padding:12px 32px;font-size:1rem;">Login</a>
  </div>

  <p style="margin-top:24px;font-size:0.8rem;color:var(--text-muted);font-family:var(--font-mono);">
    Assignment Project · MBAI MANDAK GILBERT KEVIN
  </p>
</div>

<script src="assets/js/main.js"></script>
</body>
</html>
