# 🐙 GitHub Explorer

**Student:** Mbai Mandak Gilbert Kevin  
**Project:** GitHub Explorer Web App

---

## 📁 Project Structure

```
github-explorer/
├── index.html              ← App entry point
│
├── assets/
│   ├── icons/              ← App icons (favicon, etc.)
│   └── images/             ← Static images
│
├── pages/
│   ├── templates.js        ← HTML templates for all screens
│   └── router.js           ← Client-side SPA router
│
├── css/
│   └── main.css            ← All styles (dark theme, components)
│
├── controller/
│   └── controllers.js      ← Feature controllers (Auth, Search, etc.)
│
└── database/
    └── db.js               ← Mock database + CRUD operations
```

---

## 📱 Screens Implemented

| # | Screen       | Feature |
|---|-------------|---------|
| 1 | Login        | Auth with username/password |
| 2 | Search Repo  | Live search with debounce |
| 3 | Repo Details | Full repo info + star toggle |
| 4 | Starred      | List of starred repos |
| 5 | Profile      | User profile + my repos |
| 6 | Settings     | Toggles + sign out |

---

## 🚀 How to Run

Just open `index.html` in any browser — no build step needed.

**Demo credentials:**
- Username: `mbai_gilbert`
- Password: `password123`

---

## 🛠 Tech Stack

- Vanilla HTML / CSS / JavaScript
- JetBrains Mono + Sora fonts
- LocalStorage for session persistence
- SPA Router (no framework)
