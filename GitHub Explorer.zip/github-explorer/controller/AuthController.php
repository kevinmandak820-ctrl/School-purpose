<?php
require_once '../database/db.php';
session_start();

class AuthController {

    public function login($email, $password) {
        $conn = getConnection();
        $stmt = $conn->prepare("SELECT * FROM users WHERE email = ?");
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $result = $stmt->get_result();
        $user = $result->fetch_assoc();

        if ($user && password_verify($password, $user['password'])) {
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['username'] = $user['username'];
            $_SESSION['email'] = $user['email'];
            $_SESSION['avatar'] = $user['avatar'];
            $conn->close();
            return ['success' => true, 'message' => 'Login successful'];
        }
        $conn->close();
        return ['success' => false, 'message' => 'Invalid email or password'];
    }

    public function register($username, $email, $password) {
        $conn = getConnection();

        // Check if exists
        $stmt = $conn->prepare("SELECT id FROM users WHERE email = ? OR username = ?");
        $stmt->bind_param("ss", $email, $username);
        $stmt->execute();
        if ($stmt->get_result()->num_rows > 0) {
            $conn->close();
            return ['success' => false, 'message' => 'Username or email already exists'];
        }

        $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
        $stmt = $conn->prepare("INSERT INTO users (username, email, password) VALUES (?, ?, ?)");
        $stmt->bind_param("sss", $username, $email, $hashedPassword);

        if ($stmt->execute()) {
            $conn->close();
            return ['success' => true, 'message' => 'Registration successful'];
        }
        $conn->close();
        return ['success' => false, 'message' => 'Registration failed'];
    }

    public function logout() {
        session_destroy();
        header('Location: ../index.php');
        exit();
    }

    public function isLoggedIn() {
        return isset($_SESSION['user_id']);
    }
}

// Handle form requests
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $auth = new AuthController();
    $action = $_POST['action'] ?? '';

    if ($action === 'login') {
        $result = $auth->login($_POST['email'] ?? '', $_POST['password'] ?? '');
        if ($result['success']) {
            header('Location: ../pages/search.php');
            exit();
        } else {
            $_SESSION['error'] = $result['message'];
            header('Location: ../pages/login.php');
            exit();
        }
    } elseif ($action === 'register') {
        $result = $auth->register($_POST['username'] ?? '', $_POST['email'] ?? '', $_POST['password'] ?? '');
        if ($result['success']) {
            $_SESSION['success'] = 'Account created! Please log in.';
            header('Location: ../pages/login.php');
            exit();
        } else {
            $_SESSION['error'] = $result['message'];
            header('Location: ../pages/login.php');
            exit();
        }
    } elseif ($action === 'logout') {
        $auth->logout();
    }
}
?>
