<?php
require_once '../database/db.php';
session_start();

class ProfileController {

    public function getProfile($userId) {
        $conn = getConnection();
        $stmt = $conn->prepare("SELECT * FROM users WHERE id = ?");
        $stmt->bind_param("i", $userId);
        $stmt->execute();
        $user = $stmt->get_result()->fetch_assoc();
        $conn->close();
        return $user;
    }

    public function updateProfile($userId, $data) {
        $conn = getConnection();
        $stmt = $conn->prepare("UPDATE users SET bio = ?, location = ?, github_token = ? WHERE id = ?");
        $stmt->bind_param("sssi", $data['bio'], $data['location'], $data['github_token'], $userId);
        $result = $stmt->execute();
        $conn->close();
        return $result;
    }

    public function changePassword($userId, $currentPassword, $newPassword) {
        $conn = getConnection();
        $stmt = $conn->prepare("SELECT password FROM users WHERE id = ?");
        $stmt->bind_param("i", $userId);
        $stmt->execute();
        $user = $stmt->get_result()->fetch_assoc();

        if (!password_verify($currentPassword, $user['password'])) {
            $conn->close();
            return ['success' => false, 'message' => 'Current password is incorrect'];
        }

        $hashed = password_hash($newPassword, PASSWORD_DEFAULT);
        $stmt = $conn->prepare("UPDATE users SET password = ? WHERE id = ?");
        $stmt->bind_param("si", $hashed, $userId);
        $stmt->execute();
        $conn->close();
        return ['success' => true, 'message' => 'Password updated successfully'];
    }

    public function getSearchHistory($userId) {
        $conn = getConnection();
        $stmt = $conn->prepare("SELECT * FROM search_history WHERE user_id = ? ORDER BY searched_at DESC LIMIT 20");
        $stmt->bind_param("i", $userId);
        $stmt->execute();
        $result = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
        $conn->close();
        return $result;
    }

    public function clearSearchHistory($userId) {
        $conn = getConnection();
        $stmt = $conn->prepare("DELETE FROM search_history WHERE user_id = ?");
        $stmt->bind_param("i", $userId);
        $stmt->execute();
        $conn->close();
    }

    public function deleteAccount($userId) {
        $conn = getConnection();
        $stmt = $conn->prepare("DELETE FROM users WHERE id = ?");
        $stmt->bind_param("i", $userId);
        $stmt->execute();
        $conn->close();
        session_destroy();
    }
}

// Handle POST
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!isset($_SESSION['user_id'])) {
        header('Location: ../pages/login.php');
        exit();
    }

    $ctrl = new ProfileController();
    $action = $_POST['action'] ?? '';

    if ($action === 'update_profile') {
        $ctrl->updateProfile($_SESSION['user_id'], [
            'bio' => $_POST['bio'] ?? '',
            'location' => $_POST['location'] ?? '',
            'github_token' => $_POST['github_token'] ?? ''
        ]);
        $_SESSION['success'] = 'Profile updated!';
        header('Location: ../pages/profile.php');
        exit();
    } elseif ($action === 'change_password') {
        $result = $ctrl->changePassword($_SESSION['user_id'], $_POST['current_password'] ?? '', $_POST['new_password'] ?? '');
        $_SESSION[$result['success'] ? 'success' : 'error'] = $result['message'];
        header('Location: ../pages/settings.php');
        exit();
    } elseif ($action === 'clear_history') {
        $ctrl->clearSearchHistory($_SESSION['user_id']);
        $_SESSION['success'] = 'Search history cleared.';
        header('Location: ../pages/settings.php');
        exit();
    }
}
?>
