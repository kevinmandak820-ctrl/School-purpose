// ========================================
// CONTROLLERS
// GitHub Explorer - controllers.js
// ========================================

const AuthController = {
  init() {
    const form = document.getElementById("login-form");
    if (!form) return;
    form.addEventListener("submit", (e) => {
      e.preventDefault();
      this.handleLogin();
    });
  },

  handleLogin() {
    const username = document.getElementById("username").value.trim();
    const password = document.getElementById("password").value.trim();
    const errEl = document.getElementById("login-error");
    const btn = document.getElementById("login-btn");

    btn.classList.add("loading");
    btn.disabled = true;
    errEl.textContent = "";

    setTimeout(() => {
      const result = DB.login(username, password);
      btn.classList.remove("loading");
      btn.disabled = false;

      if (result.success) {
        Router.navigate("search");
      } else {
        errEl.textContent = result.error;
        errEl.classList.add("shake");
        setTimeout(() => errEl.classList.remove("shake"), 500);
      }
    }, 800);
  },

  logout() {
    DB.logout();
    Router.navigate("login");
  }
};

// ----------------------------------------
const SearchController = {
  debounceTimer: null,

  init() {
    const input = document.getElementById("search-input");
    const btn = document.getElementById("search-btn");
    if (!input) return;

    this.renderResults(DB.repositories);

    input.addEventListener("input", () => {
      clearTimeout(this.debounceTimer);
      this.debounceTimer = setTimeout(() => {
        this.search(input.value);
      }, 300);
    });

    if (btn) btn.addEventListener("click", () => this.search(input.value));
  },

  search(query) {
    const results = DB.searchRepos(query);
    this.renderResults(results);
  },

  renderResults(repos) {
    const container = document.getElementById("repo-list");
    if (!container) return;

    if (repos.length === 0) {
      container.innerHTML = `<div class="empty-state"><span class="icon">🔍</span><p>No repositories found</p></div>`;
      return;
    }

    container.innerHTML = repos.map(repo => `
      <div class="repo-card" onclick="Router.navigate('details', ${repo.id})">
        <div class="repo-card-header">
          <span class="repo-icon">📁</span>
          <div class="repo-title">
            <span class="repo-owner">${repo.owner}</span>
            <span class="repo-sep">/</span>
            <span class="repo-name">${repo.name}</span>
          </div>
          <button class="star-btn ${repo.isStarred ? 'starred' : ''}" onclick="event.stopPropagation(); SearchController.toggleStar(${repo.id}, this)">
            ${repo.isStarred ? '★' : '☆'}
          </button>
        </div>
        <p class="repo-desc">${repo.description}</p>
        <div class="repo-meta">
          <span class="lang-dot" style="background:${Utils.langColor(repo.language)}"></span>
          <span>${repo.language}</span>
          <span>⭐ ${Utils.formatNum(repo.stars)}</span>
          <span>🍴 ${Utils.formatNum(repo.forks)}</span>
          <span class="repo-time">Updated ${repo.updated}</span>
        </div>
        <div class="repo-topics">
          ${repo.topics.map(t => `<span class="topic">${t}</span>`).join("")}
        </div>
      </div>
    `).join("");
  },

  toggleStar(id, btn) {
    const repo = DB.toggleStar(id);
    if (repo) {
      btn.textContent = repo.isStarred ? "★" : "☆";
      btn.classList.toggle("starred", repo.isStarred);
    }
  }
};

// ----------------------------------------
const DetailsController = {
  currentId: null,

  init(id) {
    this.currentId = id;
    const repo = DB.getRepoById(id);
    if (!repo) { Router.navigate("search"); return; }
    this.render(repo);
  },

  render(repo) {
    document.getElementById("detail-name").textContent = `${repo.owner} / ${repo.name}`;
    document.getElementById("detail-desc").textContent = repo.description;
    document.getElementById("detail-stars").textContent = Utils.formatNum(repo.stars);
    document.getElementById("detail-forks").textContent = Utils.formatNum(repo.forks);
    document.getElementById("detail-watchers").textContent = Utils.formatNum(repo.watchers);
    document.getElementById("detail-issues").textContent = repo.issues;
    document.getElementById("detail-lang").textContent = repo.language;
    document.getElementById("detail-updated").textContent = repo.updated;
    document.getElementById("detail-readme").textContent = repo.readme;

    const topicsEl = document.getElementById("detail-topics");
    topicsEl.innerHTML = repo.topics.map(t => `<span class="topic">${t}</span>`).join("");

    const starBtn = document.getElementById("detail-star-btn");
    starBtn.textContent = repo.isStarred ? "★ Unstar" : "☆ Star";
    starBtn.classList.toggle("starred", repo.isStarred);

    starBtn.onclick = () => {
      const updated = DB.toggleStar(repo.id);
      starBtn.textContent = updated.isStarred ? "★ Unstar" : "☆ Star";
      starBtn.classList.toggle("starred", updated.isStarred);
      document.getElementById("detail-stars").textContent = Utils.formatNum(updated.stars);
    };
  }
};

// ----------------------------------------
const StarredController = {
  init() {
    this.render();
  },

  render() {
    const repos = DB.getStarredRepos();
    const container = document.getElementById("starred-list");
    if (!container) return;

    document.getElementById("starred-count").textContent = repos.length;

    if (repos.length === 0) {
      container.innerHTML = `<div class="empty-state"><span class="icon">⭐</span><p>No starred repositories yet</p></div>`;
      return;
    }

    container.innerHTML = repos.map(repo => `
      <div class="repo-card" onclick="Router.navigate('details', ${repo.id})">
        <div class="repo-card-header">
          <span class="repo-icon">📁</span>
          <div class="repo-title">
            <span class="repo-owner">${repo.owner}</span>
            <span class="repo-sep">/</span>
            <span class="repo-name">${repo.name}</span>
          </div>
          <button class="star-btn starred" onclick="event.stopPropagation(); StarredController.unstar(${repo.id})">★</button>
        </div>
        <p class="repo-desc">${repo.description}</p>
        <div class="repo-meta">
          <span class="lang-dot" style="background:${Utils.langColor(repo.language)}"></span>
          <span>${repo.language}</span>
          <span>⭐ ${Utils.formatNum(repo.stars)}</span>
          <span>🍴 ${Utils.formatNum(repo.forks)}</span>
        </div>
      </div>
    `).join("");
  },

  unstar(id) {
    DB.toggleStar(id);
    this.render();
  }
};

// ----------------------------------------
const ProfileController = {
  init() {
    const user = DB.currentUser || DB.getSession();
    if (!user) { Router.navigate("login"); return; }
    this.render(user);
  },

  render(user) {
    document.getElementById("profile-avatar").src = user.avatar;
    document.getElementById("profile-name").textContent = user.name;
    document.getElementById("profile-username").textContent = "@" + user.username;
    document.getElementById("profile-bio").textContent = user.bio;
    document.getElementById("profile-location").textContent = user.location;
    document.getElementById("profile-email").textContent = user.email;
    document.getElementById("profile-joined").textContent = user.joined;
    document.getElementById("profile-followers").textContent = user.followers;
    document.getElementById("profile-following").textContent = user.following;
    document.getElementById("profile-repos").textContent = user.public_repos;

    const myRepos = DB.repositories.filter(r => r.owner === user.username);
    const repoContainer = document.getElementById("profile-repos-list");
    repoContainer.innerHTML = myRepos.map(repo => `
      <div class="repo-card small" onclick="Router.navigate('details', ${repo.id})">
        <div class="repo-title"><span class="repo-name">${repo.name}</span></div>
        <p class="repo-desc">${repo.description}</p>
        <div class="repo-meta">
          <span class="lang-dot" style="background:${Utils.langColor(repo.language)}"></span>
          <span>${repo.language}</span>
          <span>⭐ ${repo.stars}</span>
        </div>
      </div>
    `).join("") || "<p class='muted'>No repositories</p>";
  }
};

// ----------------------------------------
const SettingsController = {
  init() {
    const settings = DB.getSettings();
    this.applyToUI(settings);
    this.bindEvents();
  },

  applyToUI(settings) {
    const themeToggle = document.getElementById("setting-theme");
    const notifToggle = document.getElementById("setting-notif");
    const emailToggle = document.getElementById("setting-email");
    const tfToggle = document.getElementById("setting-2fa");

    if (themeToggle) themeToggle.checked = settings.theme === "dark";
    if (notifToggle) notifToggle.checked = settings.notifications;
    if (emailToggle) emailToggle.checked = settings.emailAlerts;
    if (tfToggle) tfToggle.checked = settings.twoFactor;
  },

  bindEvents() {
    document.querySelectorAll(".settings-toggle").forEach(toggle => {
      toggle.addEventListener("change", () => this.saveSettings());
    });

    const logoutBtn = document.getElementById("logout-btn");
    if (logoutBtn) logoutBtn.addEventListener("click", () => AuthController.logout());
  },

  saveSettings() {
    const newSettings = {
      theme: document.getElementById("setting-theme")?.checked ? "dark" : "light",
      notifications: document.getElementById("setting-notif")?.checked || false,
      emailAlerts: document.getElementById("setting-email")?.checked || false,
      twoFactor: document.getElementById("setting-2fa")?.checked || false,
    };
    DB.updateSettings(newSettings);

    const toast = document.getElementById("settings-toast");
    if (toast) {
      toast.classList.add("show");
      setTimeout(() => toast.classList.remove("show"), 2000);
    }
  }
};

// ----------------------------------------
const Utils = {
  formatNum(n) {
    if (n >= 1000) return (n / 1000).toFixed(1) + "k";
    return n;
  },

  langColor(lang) {
    const map = {
      JavaScript: "#f1e05a",
      TypeScript: "#3178c6",
      Python: "#3572A5",
      React: "#61dafb",
      Go: "#00ADD8",
      CSS: "#563d7c",
      HTML: "#e34c26",
    };
    return map[lang] || "#8b949e";
  }
};
