<?php
require_once '../database/db.php';
session_start();

class GitHubController {

    private $baseUrl = 'https://api.github.com';
    private $token;

    public function __construct($token = null) {
        $this->token = $token;
    }

    private function makeRequest($endpoint) {
        $ch = curl_init();
        $url = $this->baseUrl . $endpoint;
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_USERAGENT, 'GitHub-Explorer-App');
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        $headers = ['Accept: application/vnd.github.v3+json'];
        if ($this->token) {
            $headers[] = 'Authorization: token ' . $this->token;
        }
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);

        if ($httpCode === 200) {
            return json_decode($response, true);
        }
        return null;
    }

    public function searchRepos($query, $page = 1, $perPage = 10) {
        $encoded = urlencode($query);
        $data = $this->makeRequest("/search/repositories?q={$encoded}&page={$page}&per_page={$perPage}&sort=stars");
        return $data;
    }

    public function getRepo($owner, $repo) {
        return $this->makeRequest("/repos/{$owner}/{$repo}");
    }

    public function getRepoReadme($owner, $repo) {
        $data = $this->makeRequest("/repos/{$owner}/{$repo}/readme");
        if ($data && isset($data['content'])) {
            return base64_decode($data['content']);
        }
        return null;
    }

    public function getRepoLanguages($owner, $repo) {
        return $this->makeRequest("/repos/{$owner}/{$repo}/languages");
    }

    public function getRepoContributors($owner, $repo) {
        return $this->makeRequest("/repos/{$owner}/{$repo}/contributors?per_page=5");
    }

    public function getUserProfile($username) {
        return $this->makeRequest("/users/{$username}");
    }

    public function saveSearchHistory($userId, $query) {
        $conn = getConnection();
        $stmt = $conn->prepare("INSERT INTO search_history (user_id, query) VALUES (?, ?)");
        $stmt->bind_param("is", $userId, $query);
        $stmt->execute();
        $conn->close();
    }

    public function starRepo($userId, $repoData) {
        $conn = getConnection();
        $stmt = $conn->prepare("INSERT IGNORE INTO starred_repos (user_id, repo_name, repo_full_name, repo_url, description, language, stars, forks) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("isssssii",
            $userId,
            $repoData['name'],
            $repoData['full_name'],
            $repoData['html_url'],
            $repoData['description'],
            $repoData['language'],
            $repoData['stargazers_count'],
            $repoData['forks_count']
        );
        $result = $stmt->execute();
        $conn->close();
        return $result;
    }

    public function unstarRepo($userId, $repoFullName) {
        $conn = getConnection();
        $stmt = $conn->prepare("DELETE FROM starred_repos WHERE user_id = ? AND repo_full_name = ?");
        $stmt->bind_param("is", $userId, $repoFullName);
        $stmt->execute();
        $conn->close();
    }

    public function getStarredRepos($userId) {
        $conn = getConnection();
        $stmt = $conn->prepare("SELECT * FROM starred_repos WHERE user_id = ? ORDER BY starred_at DESC");
        $stmt->bind_param("i", $userId);
        $stmt->execute();
        $result = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
        $conn->close();
        return $result;
    }

    public function isStarred($userId, $repoFullName) {
        $conn = getConnection();
        $stmt = $conn->prepare("SELECT id FROM starred_repos WHERE user_id = ? AND repo_full_name = ?");
        $stmt->bind_param("is", $userId, $repoFullName);
        $stmt->execute();
        $count = $stmt->get_result()->num_rows;
        $conn->close();
        return $count > 0;
    }
}

// Handle AJAX requests
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['ajax'])) {
    header('Content-Type: application/json');
    $gh = new GitHubController();
    $action = $_POST['action'] ?? '';

    if ($action === 'star') {
        if (!isset($_SESSION['user_id'])) { echo json_encode(['success' => false]); exit(); }
        $repoData = json_decode($_POST['repo_data'], true);
        $result = $gh->starRepo($_SESSION['user_id'], $repoData);
        echo json_encode(['success' => $result]);
    } elseif ($action === 'unstar') {
        if (!isset($_SESSION['user_id'])) { echo json_encode(['success' => false]); exit(); }
        $gh->unstarRepo($_SESSION['user_id'], $_POST['repo_full_name']);
        echo json_encode(['success' => true]);
    } elseif ($action === 'check_star') {
        if (!isset($_SESSION['user_id'])) { echo json_encode(['starred' => false]); exit(); }
        $starred = $gh->isStarred($_SESSION['user_id'], $_POST['repo_full_name']);
        echo json_encode(['starred' => $starred]);
    }
    exit();
}
?>
