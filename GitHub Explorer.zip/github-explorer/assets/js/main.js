// GitHub Explorer — Main JS

// Active nav link
document.addEventListener('DOMContentLoaded', () => {
  const current = window.location.pathname.split('/').pop();
  document.querySelectorAll('.nav-links a').forEach(link => {
    if (link.getAttribute('href') && link.getAttribute('href').includes(current)) {
      link.classList.add('active');
    }
  });

  // Auto-dismiss alerts
  document.querySelectorAll('.alert').forEach(alert => {
    setTimeout(() => {
      alert.style.opacity = '0';
      alert.style.transition = 'opacity 0.4s';
      setTimeout(() => alert.remove(), 400);
    }, 4000);
  });
});

// Star / Unstar a repo
async function toggleStar(btn, repoData) {
  const isStarred = btn.classList.contains('starred');
  const fullName = repoData.full_name;

  try {
    const formData = new FormData();
    formData.append('ajax', '1');
    formData.append('action', isStarred ? 'unstar' : 'star');

    if (!isStarred) {
      formData.append('repo_data', JSON.stringify(repoData));
    } else {
      formData.append('repo_full_name', fullName);
    }

    const res = await fetch('../controller/GitHubController.php', { method: 'POST', body: formData });
    const data = await res.json();

    if (data.success || data.success === undefined) {
      btn.classList.toggle('starred');
      btn.innerHTML = btn.classList.contains('starred')
        ? '★ Starred'
        : '☆ Star';
    }
  } catch (e) {
    console.error('Star toggle failed', e);
  }
}

// Search with Enter key
function searchOnEnter(e, btn) {
  if (e.key === 'Enter') btn.click();
}

// Confirm dialogs
function confirmAction(msg, callback) {
  if (confirm(msg)) callback();
}

// Copy to clipboard
function copyToClipboard(text) {
  navigator.clipboard.writeText(text).then(() => {
    showToast('Copied to clipboard!');
  });
}

// Toast notification
function showToast(msg, type = 'info') {
  const toast = document.createElement('div');
  toast.className = `alert alert-${type}`;
  toast.style.cssText = 'position:fixed;bottom:24px;right:24px;z-index:9999;min-width:240px;animation:fadeIn 0.3s ease';
  toast.textContent = msg;
  document.body.appendChild(toast);
  setTimeout(() => { toast.style.opacity = '0'; toast.style.transition = 'opacity 0.4s'; setTimeout(() => toast.remove(), 400); }, 3000);
}
