-- GitHub Explorer Database Schema
CREATE DATABASE IF NOT EXISTS github_explorer;
USE github_explorer;

CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(100) NOT NULL UNIQUE,
    email VARCHAR(150) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    avatar VARCHAR(255) DEFAULT 'assets/images/default-avatar.png',
    bio TEXT,
    location VARCHAR(100),
    github_token VARCHAR(255),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS starred_repos (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    repo_name VARCHAR(200) NOT NULL,
    repo_full_name VARCHAR(255) NOT NULL,
    repo_url VARCHAR(255),
    description TEXT,
    language VARCHAR(50),
    stars INT DEFAULT 0,
    forks INT DEFAULT 0,
    starred_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    UNIQUE KEY unique_star (user_id, repo_full_name)
);

CREATE TABLE IF NOT EXISTS search_history (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    query VARCHAR(255) NOT NULL,
    searched_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- Sample user (password: password123)
INSERT IGNORE INTO users (username, email, password, bio, location) VALUES
('demo_user', 'demo@github-explorer.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'A passionate developer exploring GitHub', 'San Francisco, CA');
