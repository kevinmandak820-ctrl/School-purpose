// ========================================
// DATABASE / Mock Storage Layer
// GitHub Explorer - db.js
// ========================================

const DB = {
  currentUser: null,

  users: [
    {
      id: 1,
      username: "mbai_gilbert",
      password: "password123",
      name: "Mbai Mandak Gilbert Kevin",
      avatar: "https://avatars.githubusercontent.com/u/1?v=4",
      bio: "Full Stack Developer | Open Source Enthusiast",
      location: "Douala, Cameroon",
      email: "mbai.gilbert@github.com",
      followers: 128,
      following: 74,
      public_repos: 32,
      joined: "January 2022",
    }
  ],

  repositories: [
    {
      id: 1,
      name: "github-explorer",
      owner: "mbai_gilbert",
      description: "A mobile app to explore GitHub repositories and profiles",
      language: "JavaScript",
      stars: 245,
      forks: 38,
      watchers: 12,
      issues: 4,
      topics: ["github", "mobile", "react-native"],
      updated: "2 hours ago",
      isStarred: true,
      readme: "# GitHub Explorer\nA powerful app to explore GitHub."
    },
    {
      id: 2,
      name: "node-auth-boilerplate",
      owner: "torvalds",
      description: "Production-ready Node.js authentication boilerplate with JWT",
      language: "TypeScript",
      stars: 1892,
      forks: 312,
      watchers: 87,
      issues: 11,
      topics: ["nodejs", "auth", "jwt", "boilerplate"],
      updated: "1 day ago",
      isStarred: false,
      readme: "# Node Auth Boilerplate\nReady-to-use authentication system."
    },
    {
      id: 3,
      name: "react-dashboard-kit",
      owner: "gaearon",
      description: "Modular dashboard components for React applications",
      language: "React",
      stars: 3401,
      forks: 567,
      watchers: 204,
      issues: 23,
      topics: ["react", "dashboard", "ui", "components"],
      updated: "3 days ago",
      isStarred: true,
      readme: "# React Dashboard Kit\nBeautiful dashboard components."
    },
    {
      id: 4,
      name: "python-ml-utils",
      owner: "karpathy",
      description: "Utility functions and helpers for machine learning projects",
      language: "Python",
      stars: 7823,
      forks: 1204,
      watchers: 430,
      issues: 56,
      topics: ["python", "machine-learning", "utils", "ai"],
      updated: "1 week ago",
      isStarred: false,
      readme: "# Python ML Utils\nHelpful utilities for ML projects."
    },
    {
      id: 5,
      name: "css-animation-library",
      owner: "mbai_gilbert",
      description: "Lightweight CSS animation library — zero dependencies",
      language: "CSS",
      stars: 512,
      forks: 89,
      watchers: 31,
      issues: 7,
      topics: ["css", "animation", "frontend"],
      updated: "5 days ago",
      isStarred: true,
      readme: "# CSS Animation Library\nSmooth animations with pure CSS."
    },
    {
      id: 6,
      name: "go-microservices-template",
      owner: "mitchellh",
      description: "Template for building microservices with Go and Docker",
      language: "Go",
      stars: 2109,
      forks: 398,
      watchers: 115,
      issues: 18,
      topics: ["go", "microservices", "docker", "kubernetes"],
      updated: "2 weeks ago",
      isStarred: false,
      readme: "# Go Microservices Template\nProduction-ready Go microservices."
    }
  ],

  settings: {
    theme: "dark",
    notifications: true,
    emailAlerts: false,
    twoFactor: false,
    language: "English",
    perPage: 10,
  },

  // CRUD methods
  login(username, password) {
    const user = this.users.find(u => u.username === username && u.password === password);
    if (user) {
      this.currentUser = user;
      localStorage.setItem("gh_user", JSON.stringify(user));
      return { success: true, user };
    }
    return { success: false, error: "Invalid credentials" };
  },

  logout() {
    this.currentUser = null;
    localStorage.removeItem("gh_user");
  },

  getSession() {
    const stored = localStorage.getItem("gh_user");
    if (stored) {
      this.currentUser = JSON.parse(stored);
      return this.currentUser;
    }
    return null;
  },

  searchRepos(query) {
    if (!query) return this.repositories;
    const q = query.toLowerCase();
    return this.repositories.filter(r =>
      r.name.toLowerCase().includes(q) ||
      r.description.toLowerCase().includes(q) ||
      r.language.toLowerCase().includes(q) ||
      r.owner.toLowerCase().includes(q)
    );
  },

  getRepoById(id) {
    return this.repositories.find(r => r.id === parseInt(id));
  },

  getStarredRepos() {
    return this.repositories.filter(r => r.isStarred);
  },

  toggleStar(id) {
    const repo = this.repositories.find(r => r.id === parseInt(id));
    if (repo) {
      repo.isStarred = !repo.isStarred;
      repo.stars += repo.isStarred ? 1 : -1;
    }
    return repo;
  },

  updateSettings(newSettings) {
    this.settings = { ...this.settings, ...newSettings };
    localStorage.setItem("gh_settings", JSON.stringify(this.settings));
  },

  getSettings() {
    const stored = localStorage.getItem("gh_settings");
    if (stored) this.settings = JSON.parse(stored);
    return this.settings;
  }
};
