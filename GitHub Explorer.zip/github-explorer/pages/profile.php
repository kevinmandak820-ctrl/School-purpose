<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

require_once '../controller/ProfileController.php';
require_once '../controller/GitHubController.php';

$ctrl = new ProfileController();
$gh = new GitHubController();

$user = $ctrl->getProfile($_SESSION['user_id']);
$starred = $gh->getStarredRepos($_SESSION['user_id']);
$history = $ctrl->getSearchHistory($_SESSION['user_id']);
$initials = strtoupper(substr($user['username'], 0, 2));

$success = $_SESSION['success'] ?? null;
unset($_SESSION['success']);
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Profile — GitHub Explorer</title>
  <link rel="stylesheet" href="../css/style.css">
</head>
<body>
<?php include 'navbar.php'; ?>

<div class="container">
  <?php if ($success): ?>
  <div class="alert alert-success">✓ <?= htmlspecialchars($success) ?></div>
  <?php endif; ?>

  <!-- Profile Header -->
  <div class="profile-header">
    <div class="profile-avatar-large"><?= $initials ?></div>
    <div class="profile-info">
      <h2>@<?= htmlspecialchars($user['username']) ?></h2>
      <p><?= htmlspecialchars($user['email']) ?></p>
      <?php if ($user['bio']): ?>
      <p style="margin-top:6px;color:var(--text-secondary)"><?= htmlspecialchars($user['bio']) ?></p>
      <?php endif; ?>
      <?php if ($user['location']): ?>
      <p style="margin-top:4px;font-size:0.8rem;color:var(--text-muted)">📍 <?= htmlspecialchars($user['location']) ?></p>
      <?php endif; ?>
      <div style="margin-top:12px;">
        <a href="settings.php" class="btn btn-secondary" style="font-size:0.8rem;padding:6px 14px;">⚙ Edit Profile</a>
      </div>
    </div>
  </div>

  <!-- Stats -->
  <div class="stats-grid">
    <div class="stat-card">
      <div class="stat-num"><?= count($starred) ?></div>
      <div class="stat-label">Starred Repos</div>
    </div>
    <div class="stat-card">
      <div class="stat-num"><?= count($history) ?></div>
      <div class="stat-label">Searches Made</div>
    </div>
    <div class="stat-card">
      <div class="stat-num"><?= date('M Y', strtotime($user['created_at'])) ?></div>
      <div class="stat-label">Member Since</div>
    </div>
  </div>

  <!-- Edit Profile Form -->
  <div class="card" style="margin-bottom:20px;">
    <h3 style="margin-bottom:20px;font-size:1rem;">Edit Profile</h3>
    <form method="POST" action="../controller/ProfileController.php">
      <input type="hidden" name="action" value="update_profile">
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:16px;">
        <div class="form-group">
          <label class="form-label">Bio</label>
          <textarea name="bio" class="form-textarea" placeholder="Tell us about yourself..."><?= htmlspecialchars($user['bio'] ?? '') ?></textarea>
        </div>
        <div>
          <div class="form-group">
            <label class="form-label">Location</label>
            <input type="text" name="location" class="form-input" value="<?= htmlspecialchars($user['location'] ?? '') ?>" placeholder="City, Country">
          </div>
          <div class="form-group">
            <label class="form-label">GitHub Token (optional)</label>
            <input type="password" name="github_token" class="form-input" value="<?= htmlspecialchars($user['github_token'] ?? '') ?>" placeholder="ghp_xxxxx for higher API limit">
          </div>
        </div>
      </div>
      <button type="submit" class="btn btn-primary">Save Changes</button>
    </form>
  </div>

  <!-- Recent Searches -->
  <div class="card">
    <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:16px;">
      <h3 style="font-size:1rem;">Recent Searches</h3>
      <?php if ($history): ?>
      <form method="POST" action="../controller/ProfileController.php">
        <input type="hidden" name="action" value="clear_history">
        <button type="submit" class="btn btn-danger" style="font-size:0.8rem;padding:5px 12px;">Clear All</button>
      </form>
      <?php endif; ?>
    </div>
    <?php if (empty($history)): ?>
      <p style="color:var(--text-secondary);font-size:0.875rem;">No searches yet.</p>
    <?php else: ?>
      <div style="display:flex;flex-wrap:wrap;gap:8px;">
        <?php foreach ($history as $h): ?>
        <a href="search.php?q=<?= urlencode($h['query']) ?>" class="badge badge-blue" style="text-decoration:none;cursor:pointer;">
          🔍 <?= htmlspecialchars($h['query']) ?>
        </a>
        <?php endforeach; ?>
      </div>
    <?php endif; ?>
  </div>
</div>

<script src="../assets/js/main.js"></script>
</body>
</html>
