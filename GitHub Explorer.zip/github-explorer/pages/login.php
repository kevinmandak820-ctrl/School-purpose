<?php
session_start();
if (isset($_SESSION['user_id'])) {
    header('Location: search.php');
    exit();
}
$error = $_SESSION['error'] ?? null;
$success = $_SESSION['success'] ?? null;
unset($_SESSION['error'], $_SESSION['success']);
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Login — GitHub Explorer</title>
  <link rel="stylesheet" href="../css/style.css">
</head>
<body>
<div class="auth-page">
  <div class="auth-box">
    <div class="auth-logo">
      <div class="big-icon">⬡</div>
      <h1>GitExplorer</h1>
      <p>Explore GitHub, your way</p>
    </div>

    <?php if ($error): ?>
      <div class="alert alert-error">⚠ <?= htmlspecialchars($error) ?></div>
    <?php endif; ?>
    <?php if ($success): ?>
      <div class="alert alert-success">✓ <?= htmlspecialchars($success) ?></div>
    <?php endif; ?>

    <!-- Tabs -->
    <div class="auth-tabs">
      <button class="auth-tab active" id="tab-login" onclick="switchTab('login')">Sign In</button>
      <button class="auth-tab" id="tab-register" onclick="switchTab('register')">Register</button>
    </div>

    <!-- Login Form -->
    <form id="form-login" method="POST" action="../controller/AuthController.php">
      <input type="hidden" name="action" value="login">
      <div class="form-group">
        <label class="form-label">Email</label>
        <input type="email" name="email" class="form-input" placeholder="you@example.com" required>
      </div>
      <div class="form-group">
        <label class="form-label">Password</label>
        <input type="password" name="password" class="form-input" placeholder="••••••••" required>
      </div>
      <button type="submit" class="btn btn-primary" style="width:100%;justify-content:center;">Sign In →</button>
      <p style="text-align:center;margin-top:14px;font-size:0.8rem;color:var(--text-muted);">
        Demo: demo@github-explorer.com / password123
      </p>
    </form>

    <!-- Register Form -->
    <form id="form-register" method="POST" action="../controller/AuthController.php" style="display:none">
      <input type="hidden" name="action" value="register">
      <div class="form-group">
        <label class="form-label">Username</label>
        <input type="text" name="username" class="form-input" placeholder="cool_dev" required>
      </div>
      <div class="form-group">
        <label class="form-label">Email</label>
        <input type="email" name="email" class="form-input" placeholder="you@example.com" required>
      </div>
      <div class="form-group">
        <label class="form-label">Password</label>
        <input type="password" name="password" class="form-input" placeholder="Min 8 characters" minlength="8" required>
      </div>
      <button type="submit" class="btn btn-primary" style="width:100%;justify-content:center;">Create Account →</button>
    </form>
  </div>
</div>

<script src="../assets/js/main.js"></script>
<script>
function switchTab(tab) {
  document.getElementById('form-login').style.display = tab === 'login' ? 'block' : 'none';
  document.getElementById('form-register').style.display = tab === 'register' ? 'block' : 'none';
  document.getElementById('tab-login').classList.toggle('active', tab === 'login');
  document.getElementById('tab-register').classList.toggle('active', tab === 'register');
}
</script>
</body>
</html>
