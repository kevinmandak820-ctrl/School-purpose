<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

require_once '../controller/GitHubController.php';

$gh = new GitHubController();
$query = trim($_GET['q'] ?? '');
$page = max(1, (int)($_GET['page'] ?? 1));
$results = null;
$totalCount = 0;

if ($query) {
    $gh->saveSearchHistory($_SESSION['user_id'], $query);
    $results = $gh->searchRepos($query, $page, 10);
    if ($results) $totalCount = min($results['total_count'], 100);
}

$totalPages = $totalCount > 0 ? ceil($totalCount / 10) : 0;
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Search — GitHub Explorer</title>
  <link rel="stylesheet" href="../css/style.css">
</head>
<body>
<?php include 'navbar.php'; ?>

<div class="container">
  <div class="page-header">
    <h1>🔍 Search Repositories</h1>
    <p>Find open-source projects on GitHub</p>
  </div>

  <!-- Search Bar -->
  <div class="search-bar">
    <div class="search-input-wrap">
      <span class="search-icon">🔍</span>
      <input type="text" id="searchInput" class="form-input" placeholder="Search repositories... (e.g. react dashboard, python api)" value="<?= htmlspecialchars($query) ?>" onkeydown="searchOnEnter(event, document.getElementById('searchBtn'))">
    </div>
    <button id="searchBtn" class="btn btn-primary" onclick="doSearch()">Search</button>
  </div>

  <?php if ($query && $results): ?>
    <p style="color:var(--text-secondary);font-size:0.875rem;margin-bottom:20px;">
      Found <strong style="color:var(--text-primary)"><?= number_format($results['total_count']) ?></strong> repositories for "<strong style="color:var(--accent)"><?= htmlspecialchars($query) ?></strong>"
    </p>

    <?php foreach ($results['items'] as $repo): ?>
    <div class="repo-card" onclick="window.location='repo-detail.php?owner=<?= urlencode($repo['owner']['login']) ?>&repo=<?= urlencode($repo['name']) ?>'">
      <div class="repo-card-header">
        <div>
          <div class="repo-name">
            <img src="<?= htmlspecialchars($repo['owner']['avatar_url']) ?>" alt="" style="width:18px;height:18px;border-radius:50%;vertical-align:middle;margin-right:6px;">
            <?= htmlspecialchars($repo['full_name']) ?>
          </div>
        </div>
        <div onclick="event.stopPropagation()">
          <button class="btn btn-star" id="star-<?= md5($repo['full_name']) ?>"
            onclick="handleStar(this, <?= htmlspecialchars(json_encode([
              'name' => $repo['name'],
              'full_name' => $repo['full_name'],
              'html_url' => $repo['html_url'],
              'description' => $repo['description'] ?? '',
              'language' => $repo['language'] ?? '',
              'stargazers_count' => $repo['stargazers_count'],
              'forks_count' => $repo['forks_count']
            ])) ?>)">
            ☆ Star
          </button>
        </div>
      </div>

      <p class="repo-description"><?= htmlspecialchars($repo['description'] ?? 'No description provided.') ?></p>

      <div class="repo-meta">
        <?php if ($repo['language']): ?>
        <span><span class="lang-dot"></span><?= htmlspecialchars($repo['language']) ?></span>
        <?php endif; ?>
        <span>★ <?= number_format($repo['stargazers_count']) ?></span>
        <span>⑂ <?= number_format($repo['forks_count']) ?></span>
        <?php if ($repo['license']): ?>
        <span>⚖ <?= htmlspecialchars($repo['license']['spdx_id']) ?></span>
        <?php endif; ?>
        <span style="margin-left:auto;">Updated <?= date('M j, Y', strtotime($repo['updated_at'])) ?></span>
      </div>
    </div>
    <?php endforeach; ?>

    <!-- Pagination -->
    <?php if ($totalPages > 1): ?>
    <div class="pagination">
      <?php if ($page > 1): ?>
        <a href="?q=<?= urlencode($query) ?>&page=<?= $page - 1 ?>" class="page-btn">‹</a>
      <?php endif; ?>

      <?php for ($i = max(1, $page - 2); $i <= min($totalPages, $page + 2); $i++): ?>
        <a href="?q=<?= urlencode($query) ?>&page=<?= $i ?>" class="page-btn <?= $i == $page ? 'active' : '' ?>"><?= $i ?></a>
      <?php endfor; ?>

      <?php if ($page < $totalPages): ?>
        <a href="?q=<?= urlencode($query) ?>&page=<?= $page + 1 ?>" class="page-btn">›</a>
      <?php endif; ?>
    </div>
    <?php endif; ?>

  <?php elseif ($query && !$results): ?>
    <div class="alert alert-error">⚠ Could not fetch results. Check your internet connection or GitHub API rate limit.</div>

  <?php else: ?>
    <div class="empty-state">
      <div class="empty-icon">🔭</div>
      <h3>Start Exploring</h3>
      <p>Search for repositories, frameworks, tools, or anything on GitHub</p>
    </div>
  <?php endif; ?>
</div>

<script src="../assets/js/main.js"></script>
<script>
function doSearch() {
  const q = document.getElementById('searchInput').value.trim();
  if (q) window.location.href = 'search.php?q=' + encodeURIComponent(q);
}

async function handleStar(btn, repoData) {
  await toggleStar(btn, repoData);
}

// Check star status on load
document.addEventListener('DOMContentLoaded', () => {
  document.querySelectorAll('.btn-star').forEach(btn => {
    const repoData = JSON.parse(btn.getAttribute('onclick').match(/handleStar\(this, (.+)\)/)?.[1] || '{}');
    if (!repoData.full_name) return;
    const fd = new FormData();
    fd.append('ajax', '1');
    fd.append('action', 'check_star');
    fd.append('repo_full_name', repoData.full_name);
    fetch('../controller/GitHubController.php', { method: 'POST', body: fd })
      .then(r => r.json())
      .then(d => {
        if (d.starred) {
          btn.classList.add('starred');
          btn.textContent = '★ Starred';
        }
      });
  });
});
</script>
</body>
</html>
