<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

require_once '../controller/GitHubController.php';

$owner = $_GET['owner'] ?? '';
$repoName = $_GET['repo'] ?? '';

if (!$owner || !$repoName) {
    header('Location: search.php');
    exit();
}

$gh = new GitHubController();
$repo = $gh->getRepo($owner, $repoName);
$languages = $gh->getRepoLanguages($owner, $repoName);
$contributors = $gh->getRepoContributors($owner, $repoName);
$readme = $gh->getRepoReadme($owner, $repoName);

$isStarred = $gh->isStarred($_SESSION['user_id'], "$owner/$repoName");

// Language colors
$langColors = ['JavaScript'=>'#f1e05a','Python'=>'#3572A5','PHP'=>'#4F5D95','TypeScript'=>'#2b7489','Java'=>'#b07219','C++'=>'#f34b7d','Ruby'=>'#701516','Go'=>'#00ADD8','Rust'=>'#dea584','CSS'=>'#563d7c','HTML'=>'#e34c26','Swift'=>'#ffac45','Kotlin'=>'#F18E33'];

$totalBytes = array_sum($languages ?: []);
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title><?= htmlspecialchars($repo['full_name'] ?? 'Repo') ?> — GitHub Explorer</title>
  <link rel="stylesheet" href="../css/style.css">
</head>
<body>
<?php include 'navbar.php'; ?>

<div class="container">
  <?php if (!$repo): ?>
    <div class="alert alert-error">⚠ Repository not found or API limit reached.</div>
    <a href="search.php" class="btn btn-secondary">← Back to Search</a>
  <?php else: ?>

  <!-- Breadcrumb -->
  <div style="margin-bottom:20px;font-size:0.875rem;color:var(--text-secondary);font-family:var(--font-mono);">
    <a href="search.php">Search</a> <span style="margin:0 8px">›</span>
    <span style="color:var(--text-primary)"><?= htmlspecialchars($repo['full_name']) ?></span>
  </div>

  <!-- Repo Header -->
  <div class="repo-detail-header">
    <div style="display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:12px;">
      <div style="display:flex;align-items:center;gap:14px;">
        <img src="<?= htmlspecialchars($repo['owner']['avatar_url']) ?>" alt="avatar" style="width:48px;height:48px;border-radius:50%;border:2px solid var(--border);">
        <div>
          <div class="repo-detail-title"><?= htmlspecialchars($repo['full_name']) ?></div>
          <div style="font-size:0.8rem;color:var(--text-secondary)"><?= $repo['private'] ? '🔒 Private' : '🌐 Public' ?></div>
        </div>
      </div>
      <div style="display:flex;gap:10px;align-items:center;">
        <button class="btn btn-star <?= $isStarred ? 'starred' : '' ?>" id="mainStarBtn"
          onclick="toggleStar(this, <?= htmlspecialchars(json_encode([
            'name' => $repo['name'],
            'full_name' => $repo['full_name'],
            'html_url' => $repo['html_url'],
            'description' => $repo['description'] ?? '',
            'language' => $repo['language'] ?? '',
            'stargazers_count' => $repo['stargazers_count'],
            'forks_count' => $repo['forks_count']
          ])) ?>)">
          <?= $isStarred ? '★ Starred' : '☆ Star' ?>
        </button>
        <a href="<?= htmlspecialchars($repo['html_url']) ?>" target="_blank" class="btn btn-secondary">View on GitHub ↗</a>
      </div>
    </div>

    <?php if ($repo['description']): ?>
    <p style="color:var(--text-secondary);margin-top:16px;line-height:1.6;"><?= htmlspecialchars($repo['description']) ?></p>
    <?php endif; ?>

    <!-- Meta badges -->
    <div class="repo-detail-meta">
      <div class="repo-meta-item">★ <strong><?= number_format($repo['stargazers_count']) ?></strong> stars</div>
      <div class="repo-meta-item">⑂ <strong><?= number_format($repo['forks_count']) ?></strong> forks</div>
      <div class="repo-meta-item">👁 <strong><?= number_format($repo['watchers_count']) ?></strong> watching</div>
      <div class="repo-meta-item">⚠ <strong><?= number_format($repo['open_issues_count']) ?></strong> issues</div>
      <?php if ($repo['license']): ?>
      <div class="repo-meta-item"><span class="badge badge-blue"><?= htmlspecialchars($repo['license']['spdx_id']) ?></span></div>
      <?php endif; ?>
      <?php if ($repo['language']): ?>
      <div class="repo-meta-item"><span class="badge badge-orange"><?= htmlspecialchars($repo['language']) ?></span></div>
      <?php endif; ?>
    </div>
  </div>

  <div style="display:grid;grid-template-columns:1fr 300px;gap:20px;align-items:start;">
    <!-- README -->
    <div>
      <h3 style="margin-bottom:14px;font-size:1rem;display:flex;align-items:center;gap:8px;">
        📄 <span>README</span>
      </h3>
      <div class="readme-box">
        <?php if ($readme): ?>
          <pre><?= htmlspecialchars(substr($readme, 0, 3000)) ?><?= strlen($readme) > 3000 ? "\n\n... [truncated] ..." : '' ?></pre>
        <?php else: ?>
          <p style="color:var(--text-secondary);font-style:italic;">No README available.</p>
        <?php endif; ?>
      </div>
    </div>

    <!-- Sidebar -->
    <div>
      <!-- Languages -->
      <?php if ($languages && $totalBytes > 0): ?>
      <div class="card" style="margin-bottom:16px;">
        <h4 style="margin-bottom:14px;font-size:0.9rem;">Languages</h4>
        <div class="lang-bar">
          <?php foreach ($languages as $lang => $bytes): ?>
            <?php $pct = round($bytes / $totalBytes * 100, 1); $color = $langColors[$lang] ?? '#8b949e'; ?>
            <div style="width:<?= $pct ?>%;background:<?= $color ?>;title='<?= htmlspecialchars($lang) ?>'"></div>
          <?php endforeach; ?>
        </div>
        <?php foreach ($languages as $lang => $bytes): ?>
          <?php $pct = round($bytes / $totalBytes * 100, 1); $color = $langColors[$lang] ?? '#8b949e'; ?>
          <div style="display:flex;justify-content:space-between;font-size:0.8rem;margin-bottom:5px;">
            <span><span style="display:inline-block;width:10px;height:10px;border-radius:50%;background:<?= $color ?>;margin-right:6px;"></span><?= htmlspecialchars($lang) ?></span>
            <span style="color:var(--text-secondary);font-family:var(--font-mono)"><?= $pct ?>%</span>
          </div>
        <?php endforeach; ?>
      </div>
      <?php endif; ?>

      <!-- Contributors -->
      <?php if ($contributors): ?>
      <div class="card" style="margin-bottom:16px;">
        <h4 style="margin-bottom:14px;font-size:0.9rem;">Top Contributors</h4>
        <?php foreach (array_slice($contributors, 0, 5) as $c): ?>
        <div style="display:flex;align-items:center;gap:10px;margin-bottom:10px;">
          <img src="<?= htmlspecialchars($c['avatar_url']) ?>" alt="" style="width:32px;height:32px;border-radius:50%;">
          <div>
            <div style="font-size:0.85rem;font-weight:600;"><?= htmlspecialchars($c['login']) ?></div>
            <div style="font-size:0.75rem;color:var(--text-secondary);font-family:var(--font-mono)"><?= number_format($c['contributions']) ?> commits</div>
          </div>
        </div>
        <?php endforeach; ?>
      </div>
      <?php endif; ?>

      <!-- Repo Info -->
      <div class="card">
        <h4 style="margin-bottom:14px;font-size:0.9rem;">Details</h4>
        <div style="font-size:0.8rem;color:var(--text-secondary);">
          <div style="margin-bottom:8px;">📅 Created: <?= date('M j, Y', strtotime($repo['created_at'])) ?></div>
          <div style="margin-bottom:8px;">🔄 Updated: <?= date('M j, Y', strtotime($repo['updated_at'])) ?></div>
          <?php if ($repo['homepage']): ?>
          <div style="margin-bottom:8px;">🔗 <a href="<?= htmlspecialchars($repo['homepage']) ?>" target="_blank">Homepage</a></div>
          <?php endif; ?>
          <div style="margin-bottom:8px;">📦 Default branch: <code style="font-family:var(--font-mono)"><?= htmlspecialchars($repo['default_branch']) ?></code></div>
          <div>
            <button onclick="copyToClipboard('git clone <?= htmlspecialchars($repo['clone_url']) ?>')" class="btn btn-secondary" style="width:100%;justify-content:center;font-size:0.8rem;margin-top:8px;">
              📋 Copy Clone URL
            </button>
          </div>
        </div>
      </div>
    </div>
  </div>

  <?php endif; ?>
</div>

<script src="../assets/js/main.js"></script>
</body>
</html>
