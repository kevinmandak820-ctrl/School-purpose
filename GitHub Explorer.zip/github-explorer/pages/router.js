// ========================================
// ROUTER - pages/router.js
// ========================================

const Router = {
  current: "login",
  history: [],

  navigate(page, param) {
    const session = DB.getSession();

    // Guard auth
    if (page !== "login" && !session) {
      page = "login";
    }

    this.history.push(this.current);
    this.current = page;
    this.param = param || null;
    this.render();
  },

  back() {
    const prev = this.history.pop();
    if (prev) {
      this.current = prev;
      this.render();
    }
  },

  render() {
    const app = document.getElementById("app");
    const isLogin = this.current === "login";

    // Show/hide nav and tab bar
    document.getElementById("top-nav").style.display = isLogin ? "none" : "";
    document.getElementById("tab-bar").style.display = isLogin ? "none" : "";

    // Set page content
    const pageEl = document.getElementById("page-content");
    pageEl.innerHTML = Pages[this.current] || "";

    // Update tab active state
    document.querySelectorAll(".tab-item").forEach(t => {
      t.classList.toggle("active", t.dataset.page === this.current);
    });

    // Init controller for current page
    switch (this.current) {
      case "login":    AuthController.init(); break;
      case "search":   SearchController.init(); break;
      case "details":  DetailsController.init(this.param); break;
      case "starred":  StarredController.init(); break;
      case "profile":  ProfileController.init(); break;
      case "settings": SettingsController.init(); break;
    }

    // Scroll to top
    pageEl.scrollTop = 0;
    window.scrollTo(0, 0);
  }
};
