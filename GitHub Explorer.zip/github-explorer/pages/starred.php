<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

require_once '../controller/GitHubController.php';

$gh = new GitHubController();
$starred = $gh->getStarredRepos($_SESSION['user_id']);

// Filter by language
$filterLang = $_GET['lang'] ?? '';
$languages = array_unique(array_filter(array_column($starred, 'language')));
sort($languages);

if ($filterLang) {
    $starred = array_filter($starred, fn($r) => $r['language'] === $filterLang);
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Starred — GitHub Explorer</title>
  <link rel="stylesheet" href="../css/style.css">
</head>
<body>
<?php include 'navbar.php'; ?>

<div class="container">
  <div class="page-header">
    <h1>★ Starred Repositories</h1>
    <p>Repositories you've saved for later</p>
  </div>

  <?php if (!empty($languages)): ?>
  <div style="display:flex;gap:8px;flex-wrap:wrap;margin-bottom:20px;">
    <a href="starred.php" class="badge <?= !$filterLang ? 'badge-blue' : 'badge-purple' ?>" style="cursor:pointer;text-decoration:none;">All</a>
    <?php foreach ($languages as $lang): ?>
    <a href="?lang=<?= urlencode($lang) ?>" class="badge <?= $filterLang === $lang ? 'badge-blue' : 'badge-purple' ?>" style="cursor:pointer;text-decoration:none;"><?= htmlspecialchars($lang) ?></a>
    <?php endforeach; ?>
  </div>
  <?php endif; ?>

  <?php if (empty($starred)): ?>
    <div class="empty-state">
      <div class="empty-icon">★</div>
      <h3>No Starred Repos Yet</h3>
      <p>Go search for repositories and star the ones you like!</p>
      <a href="search.php" class="btn btn-primary" style="margin-top:16px;">🔍 Search Repos</a>
    </div>
  <?php else: ?>
    <p style="color:var(--text-secondary);font-size:0.875rem;margin-bottom:16px;"><?= count($starred) ?> repositories starred</p>

    <?php foreach ($starred as $repo): ?>
    <div class="repo-card">
      <div class="repo-card-header">
        <div>
          <div class="repo-name" onclick="window.location='<?= htmlspecialchars($repo['repo_url']) ?>' " style="cursor:pointer">
            <?= htmlspecialchars($repo['repo_full_name']) ?>
          </div>
        </div>
        <button class="btn btn-star starred" onclick="unstarRepo(this, '<?= htmlspecialchars($repo['repo_full_name']) ?>', this.closest('.repo-card'))">
          ★ Starred
        </button>
      </div>
      <p class="repo-description"><?= htmlspecialchars($repo['description'] ?: 'No description.') ?></p>
      <div class="repo-meta">
        <?php if ($repo['language']): ?>
        <span><span class="lang-dot"></span><?= htmlspecialchars($repo['language']) ?></span>
        <?php endif; ?>
        <span>★ <?= number_format($repo['stars']) ?></span>
        <span>⑂ <?= number_format($repo['forks']) ?></span>
        <span>Saved <?= date('M j', strtotime($repo['starred_at'])) ?></span>
        <span style="margin-left:auto;">
          <a href="<?= htmlspecialchars($repo['repo_url']) ?>" target="_blank" class="btn btn-secondary" style="padding:4px 10px;font-size:0.75rem;" onclick="event.stopPropagation()">View ↗</a>
        </span>
      </div>
    </div>
    <?php endforeach; ?>
  <?php endif; ?>
</div>

<script src="../assets/js/main.js"></script>
<script>
async function unstarRepo(btn, repoFullName, card) {
  const fd = new FormData();
  fd.append('ajax', '1');
  fd.append('action', 'unstar');
  fd.append('repo_full_name', repoFullName);
  const res = await fetch('../controller/GitHubController.php', { method: 'POST', body: fd });
  const data = await res.json();
  if (data.success) {
    card.style.opacity = '0';
    card.style.transition = 'opacity 0.3s';
    setTimeout(() => card.remove(), 300);
    showToast('Removed from starred', 'info');
  }
}
</script>
</body>
</html>
