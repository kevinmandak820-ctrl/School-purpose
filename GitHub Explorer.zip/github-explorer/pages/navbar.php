<?php
if (session_status() === PHP_SESSION_NONE) session_start();
$isLoggedIn = isset($_SESSION['user_id']);
$username = $_SESSION['username'] ?? '';
$initials = $username ? strtoupper(substr($username, 0, 2)) : 'GE';
?>
<nav class="navbar">
  <a href="<?= $isLoggedIn ? 'search.php' : '../index.php' ?>" class="nav-brand">
    <div class="logo-icon">⬡</div>
    <span>GitExplorer</span>
  </a>

  <?php if ($isLoggedIn): ?>
  <div class="nav-links">
    <a href="search.php"><span>🔍</span> <span>Search</span></a>
    <a href="starred.php"><span>★</span> <span>Starred</span></a>
    <a href="profile.php"><span>◉</span> <span>Profile</span></a>
    <a href="settings.php"><span>⚙</span> <span>Settings</span></a>
  </div>
  <div style="display:flex;align-items:center;gap:12px;">
    <span style="color:var(--text-secondary);font-size:0.8rem;font-family:var(--font-mono);">@<?= htmlspecialchars($username) ?></span>
    <form method="POST" action="../controller/AuthController.php" style="margin:0">
      <input type="hidden" name="action" value="logout">
      <button type="submit" class="btn btn-secondary" style="padding:6px 12px;font-size:0.8rem">Logout</button>
    </form>
  </div>
  <?php else: ?>
  <div class="nav-links">
    <a href="../pages/login.php">Login</a>
  </div>
  <?php endif; ?>
</nav>
