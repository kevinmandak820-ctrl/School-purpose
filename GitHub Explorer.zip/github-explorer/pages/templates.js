<!-- ========================================
     pages/templates.js - HTML Page Templates
======================================== -->
<script>
const Pages = {

  login: `
    <div class="login-bg"></div>
    <div class="login-card">
      <div class="login-logo">
        <div class="octocat">🐙</div>
        <h1>GitHub Explorer</h1>
        <p>Sign in to explore repositories</p>
      </div>
      <form id="login-form">
        <div class="form-group">
          <label for="username">Username</label>
          <input id="username" class="form-input" type="text" placeholder="Enter username" value="mbai_gilbert" autocomplete="off" />
        </div>
        <div class="form-group">
          <label for="password">Password</label>
          <input id="password" class="form-input" type="password" placeholder="Enter password" value="password123" />
        </div>
        <div class="login-hint">
          Demo → mbai_gilbert / password123
        </div>
        <button class="btn-primary" id="login-btn" type="submit">Sign In</button>
        <div class="error-msg" id="login-error"></div>
      </form>
    </div>
  `,

  search: `
    <div class="search-header">
      <div class="search-bar">
        <input id="search-input" class="search-input" type="text" placeholder="🔍  Search repositories..." autocomplete="off" />
        <button id="search-btn" class="search-btn">Go</button>
      </div>
      <div class="results-count" id="results-count">Showing all repositories</div>
    </div>
    <div class="repo-list" id="repo-list"></div>
  `,

  details: `
    <div class="detail-hero">
      <button class="back-btn" onclick="Router.back()">← Back</button>
      <div class="detail-title" id="detail-name">—</div>
      <div class="detail-desc" id="detail-desc">—</div>
      <div class="detail-stats">
        <div class="stat-item">⭐ <strong id="detail-stars">0</strong></div>
        <div class="stat-item">🍴 <strong id="detail-forks">0</strong></div>
        <div class="stat-item">👁 <strong id="detail-watchers">0</strong></div>
        <div class="stat-item">🐛 <strong id="detail-issues">0</strong></div>
      </div>
      <button class="detail-star-btn" id="detail-star-btn">☆ Star</button>
    </div>
    <div class="detail-body">
      <div class="detail-section">
        <h3>Info</h3>
        <div class="detail-info-grid">
          <div class="info-item">
            <div class="info-label">Language</div>
            <div class="info-value" id="detail-lang">—</div>
          </div>
          <div class="info-item">
            <div class="info-label">Last updated</div>
            <div class="info-value" id="detail-updated">—</div>
          </div>
        </div>
      </div>
      <div class="detail-section">
        <h3>Topics</h3>
        <div class="repo-topics" id="detail-topics"></div>
      </div>
      <div class="detail-section">
        <h3>README</h3>
        <div class="readme-box" id="detail-readme"></div>
      </div>
    </div>
  `,

  starred: `
    <div class="page-header">
      <h2>⭐ Starred <span class="badge" id="starred-count">0</span></h2>
    </div>
    <div class="repo-list" id="starred-list"></div>
  `,

  profile: `
    <div class="profile-hero">
      <div class="profile-avatar-wrap">
        <img id="profile-avatar" class="profile-avatar" src="" alt="avatar" />
        <div class="online-dot"></div>
      </div>
      <div class="profile-name" id="profile-name">—</div>
      <div class="profile-username" id="profile-username">—</div>
      <div class="profile-bio" id="profile-bio">—</div>
      <div class="profile-stats">
        <div class="pstat">
          <div class="pstat-val" id="profile-repos">0</div>
          <div class="pstat-label">Repos</div>
        </div>
        <div class="pstat">
          <div class="pstat-val" id="profile-followers">0</div>
          <div class="pstat-label">Followers</div>
        </div>
        <div class="pstat">
          <div class="pstat-val" id="profile-following">0</div>
          <div class="pstat-label">Following</div>
        </div>
      </div>
    </div>
    <div class="profile-body">
      <div class="info-row"><span class="icon">📍</span><span id="profile-location">—</span></div>
      <div class="info-row"><span class="icon">✉️</span><span id="profile-email">—</span></div>
      <div class="info-row"><span class="icon">📅</span><span id="profile-joined">—</span></div>
      <div class="detail-section" style="margin-top:20px">
        <div class="section-title">📁 My Repositories</div>
        <div class="repo-list" id="profile-repos-list" style="padding:0;"></div>
      </div>
    </div>
  `,

  settings: `
    <div class="page-header">
      <h2>⚙️ Settings</h2>
    </div>
    <div class="settings-body">
      <div class="settings-section">
        <div class="settings-section-title">Appearance</div>
        <div class="settings-card">
          <div class="settings-item">
            <span class="settings-item-icon">🌙</span>
            <div class="settings-item-content">
              <div class="settings-item-title">Dark Mode</div>
              <div class="settings-item-desc">Use dark theme across the app</div>
            </div>
            <div class="toggle-wrap">
              <input type="checkbox" id="setting-theme" class="toggle-input settings-toggle" checked />
              <label for="setting-theme" class="toggle-label"></label>
            </div>
          </div>
        </div>
      </div>
      <div class="settings-section">
        <div class="settings-section-title">Notifications</div>
        <div class="settings-card">
          <div class="settings-item">
            <span class="settings-item-icon">🔔</span>
            <div class="settings-item-content">
              <div class="settings-item-title">Push Notifications</div>
              <div class="settings-item-desc">Get notified about activity</div>
            </div>
            <div class="toggle-wrap">
              <input type="checkbox" id="setting-notif" class="toggle-input settings-toggle" checked />
              <label for="setting-notif" class="toggle-label"></label>
            </div>
          </div>
          <div class="settings-item">
            <span class="settings-item-icon">📧</span>
            <div class="settings-item-content">
              <div class="settings-item-title">Email Alerts</div>
              <div class="settings-item-desc">Receive email summaries</div>
            </div>
            <div class="toggle-wrap">
              <input type="checkbox" id="setting-email" class="toggle-input settings-toggle" />
              <label for="setting-email" class="toggle-label"></label>
            </div>
          </div>
        </div>
      </div>
      <div class="settings-section">
        <div class="settings-section-title">Security</div>
        <div class="settings-card">
          <div class="settings-item">
            <span class="settings-item-icon">🔐</span>
            <div class="settings-item-content">
              <div class="settings-item-title">Two-Factor Auth</div>
              <div class="settings-item-desc">Add an extra layer of security</div>
            </div>
            <div class="toggle-wrap">
              <input type="checkbox" id="setting-2fa" class="toggle-input settings-toggle" />
              <label for="setting-2fa" class="toggle-label"></label>
            </div>
          </div>
        </div>
      </div>
      <div class="settings-section">
        <div class="settings-section-title">Account</div>
        <button class="btn-danger" id="logout-btn">🚪 Sign Out</button>
      </div>
    </div>
    <div class="toast" id="settings-toast">✅ Settings saved</div>
  `

};
</script>
