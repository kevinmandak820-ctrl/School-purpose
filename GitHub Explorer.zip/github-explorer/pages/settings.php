<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

require_once '../controller/ProfileController.php';

$ctrl = new ProfileController();
$user = $ctrl->getProfile($_SESSION['user_id']);

$success = $_SESSION['success'] ?? null;
$error = $_SESSION['error'] ?? null;
unset($_SESSION['success'], $_SESSION['error']);
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Settings — GitHub Explorer</title>
  <link rel="stylesheet" href="../css/style.css">
</head>
<body>
<?php include 'navbar.php'; ?>

<div class="container">
  <div class="page-header">
    <h1>⚙ Settings</h1>
    <p>Manage your account preferences</p>
  </div>

  <?php if ($success): ?>
  <div class="alert alert-success">✓ <?= htmlspecialchars($success) ?></div>
  <?php endif; ?>
  <?php if ($error): ?>
  <div class="alert alert-error">⚠ <?= htmlspecialchars($error) ?></div>
  <?php endif; ?>

  <!-- Account Info -->
  <div class="settings-section">
    <div class="settings-section-header">👤 Account Information</div>
    <div class="settings-section-body">
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:20px;">
        <div>
          <p class="form-label">Username</p>
          <p style="font-family:var(--font-mono);color:var(--text-primary);">@<?= htmlspecialchars($user['username']) ?></p>
        </div>
        <div>
          <p class="form-label">Email</p>
          <p style="color:var(--text-primary);"><?= htmlspecialchars($user['email']) ?></p>
        </div>
        <div>
          <p class="form-label">Member Since</p>
          <p style="color:var(--text-secondary);"><?= date('F j, Y', strtotime($user['created_at'])) ?></p>
        </div>
        <div>
          <p class="form-label">Account Type</p>
          <span class="badge badge-green">Free Plan</span>
        </div>
      </div>
    </div>
  </div>

  <!-- Change Password -->
  <div class="settings-section">
    <div class="settings-section-header">🔑 Change Password</div>
    <div class="settings-section-body">
      <form method="POST" action="../controller/ProfileController.php" style="max-width:400px;">
        <input type="hidden" name="action" value="change_password">
        <div class="form-group">
          <label class="form-label">Current Password</label>
          <input type="password" name="current_password" class="form-input" placeholder="••••••••" required>
        </div>
        <div class="form-group">
          <label class="form-label">New Password</label>
          <input type="password" name="new_password" class="form-input" placeholder="Min 8 characters" minlength="8" required>
        </div>
        <div class="form-group">
          <label class="form-label">Confirm New Password</label>
          <input type="password" id="confirm_pass" class="form-input" placeholder="••••••••" required>
        </div>
        <button type="submit" class="btn btn-primary" onclick="return validatePass()">Update Password</button>
      </form>
    </div>
  </div>

  <!-- GitHub API Settings -->
  <div class="settings-section">
    <div class="settings-section-header">🐙 GitHub API Token</div>
    <div class="settings-section-body">
      <p style="font-size:0.875rem;color:var(--text-secondary);margin-bottom:16px;">
        Add a personal access token to increase your GitHub API rate limit from 60 to 5,000 requests/hour.
        <a href="https://github.com/settings/tokens" target="_blank">Generate token →</a>
      </p>
      <form method="POST" action="../controller/ProfileController.php" style="max-width:500px;">
        <input type="hidden" name="action" value="update_profile">
        <input type="hidden" name="bio" value="<?= htmlspecialchars($user['bio'] ?? '') ?>">
        <input type="hidden" name="location" value="<?= htmlspecialchars($user['location'] ?? '') ?>">
        <div class="form-group">
          <label class="form-label">Personal Access Token</label>
          <input type="password" name="github_token" class="form-input" value="<?= htmlspecialchars($user['github_token'] ?? '') ?>" placeholder="ghp_xxxxxxxxxxxx">
        </div>
        <button type="submit" class="btn btn-primary">Save Token</button>
      </form>
    </div>
  </div>

  <!-- Data & Privacy -->
  <div class="settings-section">
    <div class="settings-section-header">🗂 Data & Privacy</div>
    <div class="settings-section-body">
      <div style="display:flex;flex-direction:column;gap:14px;">
        <div style="display:flex;justify-content:space-between;align-items:center;">
          <div>
            <p style="font-weight:600;font-size:0.9rem;">Search History</p>
            <p style="font-size:0.8rem;color:var(--text-secondary)">Clear all your past search queries</p>
          </div>
          <form method="POST" action="../controller/ProfileController.php">
            <input type="hidden" name="action" value="clear_history">
            <button type="submit" class="btn btn-secondary" style="font-size:0.8rem;">Clear History</button>
          </form>
        </div>
        <hr style="border-color:var(--border);">
        <div style="display:flex;justify-content:space-between;align-items:center;">
          <div>
            <p style="font-weight:600;font-size:0.9rem;color:var(--accent-red)">Export Data</p>
            <p style="font-size:0.8rem;color:var(--text-secondary)">Download your starred repos and history</p>
          </div>
          <button class="btn btn-secondary" style="font-size:0.8rem;" onclick="exportData()">Export JSON</button>
        </div>
      </div>
    </div>
  </div>

  <!-- Requirements Info -->
  <div class="settings-section">
    <div class="settings-section-header">📋 Assignment Requirements</div>
    <div class="settings-section-body">
      <p style="font-size:0.875rem;color:var(--text-secondary);margin-bottom:14px;font-family:var(--font-mono)">Student: MBAI MANDAK GILBERT KEVIN | Project: GitHub Explorer</p>
      <div style="display:grid;grid-template-columns:repeat(2,1fr);gap:10px;">
        <?php $screens = [['✓','Login screen','Implemented with tabs (Login/Register)'],['✓','Search Repo','Full search with pagination'],['✓','Repo Details','Languages, contributors, README'],['✓','Starred','Save & manage starred repos'],['✓','Profile','User profile with stats'],['✓','Settings','This page — account settings']]; ?>
        <?php foreach ($screens as [$status, $name, $desc]): ?>
        <div style="background:var(--bg-secondary);border:1px solid var(--border);border-radius:6px;padding:12px;">
          <div style="display:flex;align-items:center;gap:8px;margin-bottom:4px;">
            <span style="color:var(--accent-green);font-weight:700"><?= $status ?></span>
            <span style="font-weight:600;font-size:0.875rem"><?= $name ?></span>
          </div>
          <p style="font-size:0.775rem;color:var(--text-secondary)"><?= $desc ?></p>
        </div>
        <?php endforeach; ?>
      </div>
    </div>
  </div>

</div>

<script src="../assets/js/main.js"></script>
<script>
function validatePass() {
  const np = document.querySelector('[name=new_password]').value;
  const cp = document.getElementById('confirm_pass').value;
  if (np !== cp) {
    showToast('Passwords do not match!', 'error');
    return false;
  }
  return true;
}

function exportData() {
  // Trigger a simple data export
  fetch('../controller/GitHubController.php', {
    method: 'POST',
    body: new URLSearchParams({ ajax: '1', action: 'export' })
  }).then(() => showToast('Export feature requires backend setup', 'info'));
}
</script>
</body>
</html>
